[Description]

writable /system/etc/hosts via mount --bind


[Steps]

1. Turn off AdAway.

2. When you see "Default hosts file restored", then flash this module and reboot.

3. After the reboot you can turn on AdAway.

4. When you see "Hosts file successfully updated", then you need to run this command in termux.

"su -c chmod 600 /etc/hosts"

(default value is 644)

5. Now check securify >:3

Note : You need to run that command every time after you update host file through AdAway.