Current Kernel Name
For Example

4.14.180-lineageos


Run this on termux

(If Magisk)
sh ./kr_offset_magisk.sh --auto --patch "-anyvalue"

OR

(If KernelSU)
sh ./kr_offset_ksu.sh --auto --patch "-anyvalue"

and reboot


Your kernel name will be

4.14.180-anyvalue

