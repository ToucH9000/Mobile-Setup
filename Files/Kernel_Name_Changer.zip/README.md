Current Kernel Name
For Example

4.14.180-lineageos


Run this on termux

sh ./kr_offset.sh --auto --patch "-anyvalue"

and reboot


Your kernel name will be

4.14.180-anyvalue

