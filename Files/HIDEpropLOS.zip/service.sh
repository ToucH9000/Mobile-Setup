# Conditional late sensitive properties
# must be set after boot_completed for various OEMs
{
	until [[ "$(getprop sys.boot_completed)" == "1" ]]; do
		sleep 1
	done

  resetprop -n ro.boot.flash.locked 1
}&