[Description]

This module is only for POCO X3 Pro (vayu) which is based on "Play Integrity Fix", "sensitive-props" and "nodebug" modules. If you want to test for other device, you need to replace "vayu" with your device codename in "module.prop" and "post-fs-data.sh".


[Credits]

ez-me
osm0sis
HuskyDG
chiteroman
rushiranpise