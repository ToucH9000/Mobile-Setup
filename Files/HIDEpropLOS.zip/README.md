[Description]

This module is only for POCO X3 Pro (vayu) which is based on "Play Integrity Fix", "sensitive-props" and "nodebug" modules. If you want to test for other device, you need to replace "vayu" with your device codename in "module.prop" and "post-fs-data.sh".

[Usage]

Repack module with working pif.json and flash.
If the json file is banned then just replace old json file with working one in "data/adb/modules/playintegrityfix"

[Credits]

ez-me
osm0sis
HuskyDG
chiteroman
rushiranpise