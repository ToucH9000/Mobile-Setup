resetprop_if_diff() {
    local NAME="$1"
    local EXPECTED="$2"
    local CURRENT="$(resetprop "$NAME")"

    [ -z "$CURRENT" ] || [ "$CURRENT" = "$EXPECTED" ] || resetprop -n "$NAME" "$EXPECTED"
}

for prefix in bootimage vendor_dlkm; do
    resetprop_if_diff ro.${prefix}.build.type user
done

for prefix in bootimage vendor_dlkm; do
    resetprop_if_diff ro.product.${prefix}.name vayu
done