#!/usr/bin/env sh
MODDIR="${0%/*}"

if [ ${KSU} = true ] ; then
	MODDIR=$MODPATH
fi

if [ -f /data/adb/modules/shadow_hosts/hosts ] ; then
 echo "old hosts file found! copying..."
 cp /data/adb/modules/shadow_hosts/hosts $MODDIR/hosts
fi

ls $MODDIR/hosts > /dev/null || cat /system/etc/hosts > $MODDIR/hosts
chcon -r u:object_r:system_file:s0 "$MODDIR/hosts"
chmod 600 $MODDIR/hosts
mount --bind "$MODDIR/hosts" /system/etc/hosts
touch -acmr /bin/ls /system/etc/hosts