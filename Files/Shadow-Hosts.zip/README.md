[Usage]

1. Disable AdAway

2. Flash module and reboot

3. Enable AdAway, after enabling AdAway, disable it (meaning : enable and disable once)

4. Flash module again and do not reboot, just close ksu.

5. Enable AdAway again

6. Check Detector UwU


[Note]

If you updated some other module (shamiko , lsposed) and rebooted. After the reboot start from "Step 3"


[Module Toggle Appearance]

When completed "Step 5", Toggle should be enabled and grayed out.