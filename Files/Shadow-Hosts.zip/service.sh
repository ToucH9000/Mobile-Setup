#!/usr/bin/env sh
MODDIR="/data/adb/modules/shadow_hosts"

until [ "$(getprop sys.boot_completed)" == "1" ]; do
    sleep 1
done


ls $MODDIR/hosts > /dev/null || cat /system/etc/hosts > $MODDIR/hosts
chcon -r u:object_r:system_file:s0 "$MODDIR/hosts"
chmod 600 $MODDIR/hosts
mount --bind "$MODDIR/hosts" /system/etc/hosts
touch -acmr /bin/ls /system/etc/hosts