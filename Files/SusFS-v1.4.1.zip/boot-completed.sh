#!/system/bin/sh

MODDIR=/data/adb/modules/susfs4ksu

SUSFS_BIN=/data/adb/ksu/bin/ksu_susfs

${SUSFS_BIN} enable_log 0

${SUSFS_BIN} add_sus_path /system/etc/hosts

resetprop -n ro.boot.vbmeta.size 9728

resetprop -n ro.boot.vbmeta.hash_alg sha256

resetprop -n ro.boot.vbmeta.avb_version 1.2

resetprop -n ro.boot.vbmeta.device_state locked

resetprop -n ro.boot.vbmeta.digest e362b13252668f07860c418006439cfb802db9a4c4c936a74fe54f2f897ff5d9

resetprop -n ro.boot.veritymode enforcing

resetprop -n ro.boot.veritymode.managed yes


# Set your kernel name to default "perf" (remove # before $ sign below)

#${SUSFS_BIN} set_uname '4.14.180-perf-g950783ac4623' 'default'