DEST_BIN_DIR=/data/adb/ksu/bin

if [ ! -d ${DEST_BIN_DIR} ]; then
    ui_print "'${DEST_BIN_DIR}' not existed, installation aborted."
    rm -rf ${MODPATH}
    exit 1
fi

unzip ${ZIPFILE} -d ${TMPDIR}/susfs

if [ ${ARCH} = "arm64" ]; then
        cp ${TMPDIR}/susfs/tools/ksu_susfs_arm64 ${DEST_BIN_DIR}/ksu_susfs
elif [ ${ARCH} = "arm" ]; then
        cp ${TMPDIR}/susfs/tools/ksu_susfs_arm ${DEST_BIN_DIR}/ksu_susfs
fi

chmod 755 ${DEST_BIN_DIR}/ksu_susfs
chmod 644 ${MODPATH}/post-fs-data.sh ${MODPATH}/service.sh ${MODPATH}/uninstall.sh

# Disable and uninstall conflict apps
APPS="
eu.xiaomi.module.inject
com.elitedevelopment.module
"

for APP in $APPS; do
    if pm list packages | grep -q "$APP"; then
        pm disable --user 0 "$APP"
        pm disable "$APP"

        pm uninstall --user 0 "$APP"
        pm uninstall "$APP"
    fi
done

rm -rf ${MODPATH}/tools
rm ${MODPATH}/customize.sh