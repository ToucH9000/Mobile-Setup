# Late sensitive properties must be set after boot_completed
{
	until [[ "$(getprop sys.boot_completed)" == "1" ]]; do
		sleep 1
	done

  resetprop -n ro.boot.flash.locked 1
  resetprop -n ro.oem_unlock_supported 0
  resetprop -n ro.secureboot.devicelock 1
  resetprop -n ro.secureboot.lockstate locked
  resetprop -n ro.com.google.acsa true
  resetprop -n ro.com.google.gmsversion 12_202207
  resetprop -n ro.boot.vbmeta.device_state locked
  resetprop -n ro.boot.vbmeta.digest a3acc7344ebd624390acbda5aba0d9703f3523667a52ae959fe7f9f3c8ee53f5
  resetprop -n ro.boot.veritymode enforcing
  resetprop -n ro.boot.veritymode.managed yes
}