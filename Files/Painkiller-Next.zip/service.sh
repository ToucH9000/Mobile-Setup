{
	until [[ "$(getprop sys.boot_completed)" == "1" ]]; do
		sleep 1
	done

  resetprop -n ro.boot.vbmeta.device_state locked
  resetprop -n ro.boot.vbmeta.digest a3acc7344ebd624390acbda5aba0d9703f3523667a52ae959fe7f9f3c8ee53f5
  resetprop -n ro.boot.veritymode enforcing
  resetprop -n ro.boot.veritymode.managed yes
}