ui_print "This module doesn't guarantee device integrity. If device integrity still fails then you need to replace pif.json with working pif.json in /data/adb."

# Check pif.json
if [ ! -f "/data/adb/pif.json" ]; then
    ui_print "! pif.json not found in /data/adb"
fi