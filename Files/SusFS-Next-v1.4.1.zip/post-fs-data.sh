#!/system/bin/sh

MODDIR=/data/adb/modules/susfs4ksu

SUSFS_BIN=/data/adb/ksu/bin/ksu_susfs

while read p; do if [ -f $p ]; then ${SUSFS_BIN} add_sus_path "$p"; fi; done < $MODDIR/UwU.txt