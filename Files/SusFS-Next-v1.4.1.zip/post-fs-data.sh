#!/system/bin/sh

MODDIR=/data/adb/modules/susfs4ksu

SUSFS_BIN=/data/adb/ksu/bin/ksu_susfs

# Hide Custom Rom
for i in $(find /system /vendor /system_ext /product -iname *lineage* -o -iname *crdroid* -o -iname *rising* -o -iname *derpfest* -o -iname *evox* -o -iname *evolutionx* -o -iname *calyx* -o -iname *gapp*) ; do ${SUSFS_BIN} add_sus_path $i ; done